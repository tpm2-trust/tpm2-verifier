tpm2-verifier debug bundle
==========================

This archive records what tpm2-ek reads from a TPM, so that its EK
certificates can be analyzed on another machine:

  manifest.json        tool version, OS, kernel, TPM sysfs and DMI vendor/model
  tpm/properties.json  TPM fixed properties (manufacturer, firmware, ...)
  tpm/info.json        the same, decoded
  tpm/nv.json          all NV indices: attributes, size, read errors
  tpm/nv/*.bin         content of the readable TCG NV indices (EK certificates,
                       certificate chains, EK templates)
  analysis/            the verification result at creation time

PRIVACY: the EK certificate uniquely identifies this TPM, and therefore this
machine. Only share the bundle with people you trust with that information.
No secrets, keys or measurements are included.

Replay it with:  tpm2-ek info -tpm bundle:<file>
